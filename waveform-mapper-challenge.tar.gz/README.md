# Waveform Segment Color Mapper - Technical Assessment

## ⏱️ Time Limit: 60 minutes

## 🎯 Overview

Build an algorithm that maps speaker segments and cut segments into a timeline suitable for rendering a colored waveform visualization in a podcast editor.

**Real-world context:** In podcast editing software, waveforms are colored by speaker. When cuts are made, those sections need to appear greyed out. Your job is to create the data structure that makes this rendering possible.

---

## 📋 Problem Statement

### Input
```typescript
speakerSegments: { start: number, end: number, speakerId: string }[]
cutSegments: { start: number, end: number }[]
```

### Output
```typescript
{ start: number, end: number, speakerId: string | 'CUT', colorKey: string }[]
```

### Requirements

**Must Do:**
1. ✅ Split speaker segments where cuts occur
2. ✅ Merge adjacent segments with same `speakerId`
3. ✅ Mark CUT segments with `speakerId='CUT'` and `colorKey='muted'`
4. ✅ Return segments in chronological order
5. ✅ Handle edge cases gracefully

**Invariants (Your code must guarantee):**
- Output segments never overlap
- Output is sorted by `start` time
- Adjacent segments have different `speakerId` or `colorKey`
- All CUT segments have `speakerId='CUT'`
- All segments have valid times (0 <= start < end)

---

## 🚀 Getting Started

### Installation
```bash
npm install
```

### Run Example
```bash
npm run dev
```

### Run Tests
```bash
npm test              # Run all tests
npm run test:watch    # Watch mode
npm run test:coverage # With coverage
```

### Type Check
```bash
npm run check
```

---

## 📁 Project Structure

```
waveform-mapper-challenge/
├── src/
│   ├── types.ts              # Type definitions (PROVIDED)
│   ├── mapper.ts             # 👈 YOUR MAIN IMPLEMENTATION
│   ├── renderer.ts           # Visualization helpers (PROVIDED)
│   ├── example.ts            # Usage examples (PROVIDED)
│   └── utils/
│       └── validation.ts     # Optional helpers (starter)
│
├── fixtures/
│   ├── basic.json           # Simple test case
│   ├── adjacent-speakers.json
│   ├── overlapping.json     # Edge case
│   ├── multiple-cuts.json
│   ├── edge-cases.json
│   └── README.md
│
├── tests/
│   └── mapper.test.ts       # Test suite (starter provided)
│
└── examples/
    └── visual-timeline.md   # ASCII visualizations
```

---

## 💡 Example

### Input
```typescript
speakerSegments: [
  { start: 0, end: 5000, speakerId: 'speaker_1' },
  { start: 5000, end: 10000, speakerId: 'speaker_2' }
]
cutSegments: [
  { start: 2000, end: 3000 }
]
```

### Expected Output
```typescript
[
  { start: 0, end: 2000, speakerId: 'speaker_1', colorKey: 'speaker_1' },
  { start: 2000, end: 3000, speakerId: 'CUT', colorKey: 'muted' },
  { start: 3000, end: 5000, speakerId: 'speaker_1', colorKey: 'speaker_1' },
  { start: 5000, end: 10000, speakerId: 'speaker_2', colorKey: 'speaker_2' }
]
```

### Visual Representation
```
Timeline: [████░░████]         [████████████████]
          0   2 3   5          10
          S1  CUT S1           S2
```

**See `examples/visual-timeline.md` for more visual examples!**

---

## 📊 Evaluation Criteria

| Criteria | Weight | What We're Looking For |
|----------|--------|------------------------|
| **Correctness** | 40% | All tests pass, handles edge cases properly |
| **Code Quality** | 25% | Clear naming, small focused functions, good structure |
| **Testing** | 20% | Comprehensive tests, test-first mindset |
| **Clarity** | 15% | Documentation, comments, invariants clearly stated |

### Scoring Breakdown

#### Correctness (40 points)
- Basic test case passes: 10 pts
- Adjacent merging works: 10 pts
- Multiple cuts handled: 10 pts
- Edge cases handled: 10 pts

#### Code Quality (25 points)
- Clear function/variable names: 8 pts
- Small, focused functions (<20 lines): 8 pts
- Good code organization: 5 pts
- No code duplication: 4 pts

#### Testing (20 points)
- Tests written for main functionality: 10 pts
- Tests written for edge cases: 5 pts
- Tests are clear and well-named: 5 pts

#### Clarity (15 points)
- Invariants documented: 5 pts
- Complex logic has comments: 5 pts
- Edge case decisions explained: 5 pts

### Bonus Points (+10)
- ✨ Excellent edge case handling (+3)
- ✨ Performance optimizations with explanation (+3)
- ✨ Creative solution to overlapping segments (+2)
- ✨ Comprehensive TypeScript types (+2)

---

## ⚠️ Edge Cases to Consider

Your implementation should handle:

- ✅ Empty inputs (no speakers, no cuts)
- ✅ Cuts without speakers
- ✅ Speakers without cuts
- ✅ Overlapping speaker segments (document your approach!)
- ✅ Overlapping cut segments (should merge)
- ✅ Adjacent cut segments (should merge)
- ✅ Cuts that exactly match speaker boundaries
- ✅ Cuts that cross speaker boundaries
- ✅ Zero-duration segments
- ✅ Invalid time ranges (end < start, negative times)
- ✅ Adjacent speakers (same speakerId - should merge)

**See `fixtures/edge-cases.json` for specific test cases!**

---

## 🎓 Implementation Tips

### Suggested Approach

1. **Start with validation** - Validate all inputs first
2. **Think in events** - Convert segments to start/end events
3. **Sort chronologically** - Process events in time order
4. **Build output** - Construct renderable segments
5. **Merge adjacent** - Combine segments with same properties
6. **Test incrementally** - Start with basic.json, work up to edge cases

### Alternative Approaches

- **Interval tree** - Build tree of all time points, then compress
- **Sweep line algorithm** - Process time points left to right
- **Recursive splitting** - Recursively split segments by cuts
- **Timeline array** - Build array of time → state, then compress

**Any approach is valid if it satisfies the invariants!**

### Performance Considerations

- With N speaker segments and M cut segments:
  - O(N + M) is achievable
  - O((N + M) log (N + M)) is acceptable
  - O(N * M) may be slow for large inputs

### What Good Code Looks Like

```typescript
// ✅ Good: Clear, documented, small functions
function validateSegment(seg: TimeSegment): void {
  if (seg.start < 0 || seg.end <= seg.start) {
    throw new SegmentValidationError('Invalid time range');
  }
}

function mergeAdjacentSegments(segs: RenderableSegment[]): RenderableSegment[] {
  // Clear logic here
}

// ❌ Avoid: Monolithic, unclear
function doEverything(speakers, cuts) {
  let result = [];
  for (let i = 0; i < speakers.length; i++) {
    // ... 100 lines of nested logic ...
  }
  return result;
}
```

---

## 📤 Submission Guidelines

When you're done:

1. ✅ Ensure all tests pass: `npm test`
2. ✅ Verify TypeScript types: `npm run check`
3. ✅ Add your explanation below in this README

### Your Implementation

**Approach Used:**
<!-- Describe your algorithm here -->

**Assumptions Made:**
<!-- List any assumptions about edge cases, overlap handling, etc. -->

**Known Limitations:**
<!-- Honest assessment of what your solution doesn't handle -->

**What I'd Improve with More Time:**
<!-- What would you add or change? -->

---

## 🧪 Testing Your Solution

### Quick Test
```bash
npm run dev
```

This runs the examples and shows visual output.

### Full Test Suite
```bash
npm test
```

### Manual Testing
```typescript
import { mapSegments } from './mapper';
import { renderSegments } from './renderer';

const result = mapSegments([...], [...]);
renderSegments(result);
```

---

## 📚 Resources

- `fixtures/README.md` - Detailed test case descriptions
- `examples/visual-timeline.md` - Visual examples with ASCII art
- `src/types.ts` - Full type definitions with JSDoc
- `tests/mapper.test.ts` - Test examples to guide your implementation

---

## ❓ Frequently Asked Questions

### Q: What should I do with overlapping speaker segments?
**A:** It's implementation-dependent! Choose one approach:
- Throw a validation error (strictest)
- First-speaker-wins (ignore later overlaps)
- Last-speaker-wins (overwrite earlier speakers)

Document your choice in code comments!

### Q: Should I handle invalid input?
**A:** Yes! Validate inputs and throw `SegmentValidationError` for invalid data (negative times, end < start, etc.)

### Q: What if there are gaps in the timeline?
**A:** That's fine! Output only segments where speakers exist or cuts exist. Gaps are allowed.

### Q: Can I add helper functions?
**A:** Absolutely! Good code is well-factored. Add as many helpers as you need.

### Q: Can I modify the type definitions?
**A:** You can add new types, but don't change the existing ones in `types.ts`.

### Q: What about performance?
**A:** Correctness > performance. But if you optimize, document why!

---

## 🎯 Success Checklist

Before submitting, verify:

- [ ] `npm test` passes all tests
- [ ] `npm run check` has no TypeScript errors
- [ ] `npm run dev` shows expected visual output
- [ ] Invariants are documented in code
- [ ] Edge case handling is explained
- [ ] You've updated the "Your Implementation" section above
- [ ] Code has clear function/variable names
- [ ] Complex logic has explanatory comments

---

## 🚀 Ready to Start?

1. Read this README carefully
2. Look at `fixtures/basic.json` and `examples/visual-timeline.md`
3. Open `src/mapper.ts` and start implementing
4. Run `npm run dev` frequently to see your progress
5. Run `npm test` to validate correctness

**Good luck! 🎉**

---

## 📞 Need Help?

If you have questions about:
- Requirements interpretation
- Ambiguous edge cases
- TypeScript compilation issues
- Jest test framework

Feel free to ask! We want you to succeed.
